<?php

ini_set("SMTP", "aspmx.l.google.com");
ini_set("sendmail_from", "saqib.00@gmail.com");

$message = "The mail message was sent with the following mail setting:\r\nSMTP = aspmx.l.google.com\r\nsmtp_port = 25\r\nsendmail_from = YourMail@address.com";

$headers = "From: saqib.00@gmail.com";

if(mail("farhan_sqb@yahoo.com", "Testing", $message, $headers)){
    echo "Check your email now....&lt;BR/>";
}else{
    echo error_get_last()['message'];
}
exit;

include_once('PHPMailer-master\src\PHPMailer.php');


$mail = new PHPMailer();

echo '<pre>';print_r($mail);exit;
// Settings
$mail->IsSMTP();
$mail->CharSet = 'UTF-8';

$mail->Host       = "mail.example.com";    // SMTP server example
$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
$mail->SMTPAuth   = true;                  // enable SMTP authentication
$mail->Port       = 25;                    // set the SMTP port for the GMAIL server
$mail->Username   = "username";            // SMTP account username example
$mail->Password   = "password";            // SMTP account password example

// Content
$mail->isHTML(true);                       // Set email format to HTML
$mail->Subject = 'Here is the subject';
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

$mail->send();



require_once ('database.php');

//Send Email Verify Code Here
$EMAIL_TO = "farhan_sqb@yahoo.com";

$EMAIL_SUBJECT = "Email Address Verification - OTP";

$EMAIL_MESSAGE = "The email verification code is: 121212";

// To send HTML mail, the Content-type header must be set
$HEARDERS  = "MIME-Version: 1.0" . "\r\n";
$HEARDERS .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";

// Additional headers

$HEARDERS .= "From: SNATCH <info@ewevolutions.com>" . "\r\n";

echo $HEARDERS;
// Send Mail
if(mail($EMAIL_TO, $EMAIL_SUBJECT, $EMAIL_MESSAGE, $HEARDERS)){
    echo 1;exit;
}else{
    echo error_get_last()['message'];
}

?>
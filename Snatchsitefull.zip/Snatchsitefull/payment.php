<?php
    require_once ('database.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Snatch | Payment information</title>
    <!-- Bootstrap css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="components/css/custom.css">
    <link rel="stylesheet" href="components/css/apply.css">
     <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
</head>

<body>
    <section class="customBox">
        <header class="text-center my-4 pb-3">
            <nav>
                <img src="components/images/blak logo.png" alt="logo">
            </nav>
        </header>

        <div class="container text-center">
            <div class="row">
                <div class="col-12 py-3">
                    <h2 class="customHeading">Setup Payment Details</h2>


                    <div class="py-3">
                        <form autocomplete="off" class="cmxform" id="applyForm" method="POST" action="payment.php">

                            <?php if(isset($errorMessage) && !empty($errorMessage)){ ?>
                                <div id="alertMsg">
                                    <p><?php echo $errorMessage; ?></p>
                                </div>
                            <?php } ?>

                            <div class="customForm">
                                <input class="form__input" type="text" id="Name" name="Name" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">Name on Card</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="cardNumber" name="cardNumber"
                                    maxlength="16" placeholder=" " autocomplete="false">
                                <span class="form__label">Card Number</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="expiry" name="expiry" maxlength="5"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">MM/YY</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="cvv" name="cvv" maxlength="3"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">CVV</span>
                            </div>

                            <div class="customForm">
                                <input class="form__input" type="text" id="zipcode" name="zipcode" maxlength="5"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">Billing ZipCode</span>
                            </div>

                            <div class="py-3">
                                <button class="customBtn" anim="ripple">Payment</button>
                            </div>
                        </form>


                    </div>

                    <p class="py-3 text-left">By submitting, I attest that the above information is accurate and true,
                        and I agree to Snatch’s
                        <a class="customLinkColor" href="#">Social Security Number Privacy Protection Policy
                        </a>,
                        <a class="customLinkColor" href="#">Electronic Communications Consent Notice
                        </a>,
                        <a class="customLinkColor" href="#">Consumer Privacy Notice
                        </a> and <a class="customLinkColor" href="#">TheHelloSign’s Terms of Use</a>.
                    </p>
                </div>
            </div>
        </div>
    </section>


    <!-- Jquery js link -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <!-- Bootstrap js link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>
    <!-- Input mask jquery plugin link -->
    <script src="components/js-code/jquery.mask.js"></script>
    <!-- custom js code -->
    <script src="components/js-code/main.js"></script>
    <!-- form validation plugin link -->
    <script src="components/js-code/jquery.validate.min.js"></script>
    <script src="components/js-code/payment.js"></script>
    <script>
        $(function () {
            $('#cardNumber').mask('9999 9999 9999 9999')
            $('#expiry').mask('99/99');
            $('#zipcode').mask('99999')
        });
    </script>
</body>

</html>
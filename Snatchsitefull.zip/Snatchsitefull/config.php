<?php
error_reporting(1);

//START SESSION
session_start();

//SET TIME ZONE GLOBALLY
date_default_timezone_set("America/Chicago");

//SET SENDER EMAIL ADDRESS FOR EMAIL GLOBALLY
define("EMAIL_FROM", "support@snatchcredit.com");

?>
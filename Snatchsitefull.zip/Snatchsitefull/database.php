<?php
    require_once('config.php');

    class Database{

        private $connection;

        public function connect_db(){
            $this->connection = mysqli_connect('localhost', 'snatchcr_snatch', '9WEZjo6;TlFy', 'snatchcr_snatch');
            if(mysqli_connect_error()){
                die("Database Connection Failed" . mysqli_connect_error() . mysqli_connect_errno());
            }
        }

        public function sanitize($value){
            $return = mysqli_real_escape_string($this->connection, $value);
            return $return;
        }

        public function check_login_details($email, $password){
            $psw = md5($password);

            $sql = "SELECT id, email, email_verify_code, is_active, applied FROM users WHERE email = '$email' AND password = '$psw'";
            $res = mysqli_query($this->connection, $sql);
            
            if($res->num_rows > 0){
                while ($row = mysqli_fetch_object($res)) {
                    $_SESSION['id'] = $row->id;
                    $_SESSION['EMAIL'] = $row->email;
                    $_SESSION['email_verify_code'] = $row->email_verify_code;
                    $_SESSION['is_active'] = $row->is_active;
                    $_SESSION['applied'] = $row->applied;
                }
                return "VALID";
            }else{
                return "INVALID";
            }
        }
        
        public function check_OTP($email, $otp){

            $sql = "SELECT id, email, email_verify_code, is_active, applied FROM users WHERE email = '$email'";
            $res = mysqli_query($this->connection, $sql);
            
            if($res->num_rows > 0){
                $dbCode = "";
                while ($row = mysqli_fetch_object($res)) {
                    $dbCode = $row->email_verify_code;
                }
                //echo $dbCode . ' - ' . $otp;exit;
                if($dbCode == $otp){
                    $sql = "SELECT id, email, email_verify_code, is_active, applied FROM users WHERE email = '$email'";
                    $res = mysqli_query($this->connection, $sql);
                    if($res->num_rows > 0){
                        while ($row = mysqli_fetch_object($res)) {
                            $_SESSION['id'] = $row->id;
                            $_SESSION['EMAIL'] = $row->email;
                            $_SESSION['email_verify_code'] = $row->email_verify_code;
                            $_SESSION['is_active'] = $row->is_active;
                            $_SESSION['applied'] = $row->applied;
                        }
                    }
                    
                    //echo '<pre>';print_r($_SESSION);exit;
                    return "MATCHED";
                }else{
                    return "INVALID";
                }
            }else{
                return "INVALID";
            }
        }

        public function make_user_active($userId){
            $sql = "UPDATE users SET is_active = 1 WHERE id = '$userId'";
            mysqli_query($this->connection, $sql);

            $_SESSION['is_active'] = 1;
            return true;
        }

        public function apply($firstName, $lastName, $mobileNumber, $birthday, $streetAddress, $city, $state, $zipcode, $SSN, $monthlyIncome, $userId){

            $sql = "UPDATE users SET firstName = '$firstName', lastName = '$lastName', mobileNumber = '$mobileNumber', birthday = '$birthday', streetAddress = '$streetAddress', 
            city = '$city', state = '$state', zipcode = '$zipcode', SSN = '$SSN', monthlyIncome = '$monthlyIncome', applied = '1' WHERE id = '$userId'";
            
            mysqli_query($this->connection, $sql);

            //Set Session Applied
            $_SESSION['applied'] = 1;

            return true;
        }

        public function register($email, $password){
            $datetime = date('Y-m-d H:i:s');
            
            //Generate 6 Digit Random Code For Email Verification
            $digits = 6;
            $code = rand(pow(10, $digits-1), pow(10, $digits)-1);

            $sql = "INSERT INTO users (email, password, created, email_verify_code, is_active) VALUES ('".$email."', '".md5($password)."', '".$datetime."', '".$code."', '0')";
            $res = mysqli_query($this->connection, $sql);
            if($res){
                return $code;
            }else{
                return false;
            }
        }
        
        public function resend_OTP($email){
            //Generate 6 Digit Random Code For Email Verification
            $digits = 6;
            $code = rand(pow(10, $digits-1), pow(10, $digits)-1);

            $sql = "UPDATE users SET email_verify_code = '".$code."' WHERE email = '".$email."'";
            $res = mysqli_query($this->connection, $sql);
            if($res){
                return $code;
            }else{
                return false;
            }
        }
        
        public function send_forgot_code($email){
            //Generate 6 Digit Random Code For Email Verification
            $digits = 6;
            $code = rand(pow(10, $digits-1), pow(10, $digits)-1);

            $sqlS = "SELECT * FROM users WHERE email = '".$email."'";
            $resS = mysqli_query($this->connection, $sqlS);
            
            if($resS->num_rows > 0){
                $sql = "UPDATE users SET forgot_verify_code = '".$code."' WHERE email = '".$email."'";
                $res = mysqli_query($this->connection, $sql);
                
                if($res){
                    $_SESSION['forgot_email'] = $email;
                    $_SESSION['forgot_code'] = $code;
                    
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        public function update_Password($email, $pass){
            $sql = "UPDATE users SET password = '".md5($pass)."' WHERE email = '".$email."'";
            //echo $sql;exit;
            $res = mysqli_query($this->connection, $sql);
            
            if($res){
                if(isset($_SESSION['forgot_email']))
                    unset($_SESSION['forgot_email']);
                if(isset($_SESSION['forgot_code']))
                    unset($_SESSION['forgot_code']);
                
                return true;
            }else{
                return false;
            }
        }

        public function check_duplicate($email){
            $sql = "SELECT id FROM users WHERE email = '$email'";
            $res = mysqli_query($this->connection, $sql);
            
            if($res->num_rows > 0){
                return "DUPLICATE";
            }else{
                return "NEW";
            }
        }

        public function retrive_db_data($tableName){
            $sql = "SELECT * FROM " . $tableName;
            $res = mysqli_query($this->connection, $sql);
            
            return $res;
        }
    }

    $database = new Database();
    $database->connect_db();
 
?>
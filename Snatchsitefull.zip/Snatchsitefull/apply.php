<?php
    require_once ('database.php');
    //echo '<pre>';print_r($_SESSION);exit;
    if(isset($_SESSION['is_active']) && $_SESSION['is_active'] == 0){
        header('Location: register-confirm.php');
    }else if(isset($_SESSION['applied']) && $_SESSION['applied'] == 1){
        header('Location: profile.php');
    }

    if( !isset($_SESSION['EMAIL']) ){
        header('Location: register.php');
    }

    $errorMessage = "";
    if(isset($_POST) & !empty($_POST)){
        
        $firstName = $database->sanitize($_POST['firstName']);
        $lastName = $database->sanitize($_POST['lastName']);
        $mobileNumber = $database->sanitize($_POST['mobileNumber']);
        $birthday = $database->sanitize($_POST['birthday']);
        $streetAddress = $database->sanitize($_POST['streetAddress']);
        $city = $database->sanitize($_POST['city']);
        $state = $database->sanitize($_POST['state']);
        $zipcode = $database->sanitize($_POST['zipcode']);
        $SSN = $database->sanitize($_POST['SSN']);
        $monthlyIncome = $database->sanitize($_POST['monthlyIncome']);
        
        //Check Duplicate
        $res = $database->apply($firstName, $lastName, $mobileNumber, $birthday, $streetAddress, $city, $state, $zipcode, $SSN, $monthlyIncome, $_SESSION['id']);

        if($res){
            //Continue the Profile Page
            header('Location: profile.php');
        }else{
            $errorMessage = "An error has occured. Please contact support@snatchcredit.com";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application | Snatch credit building tool</title>
    <!-- Bootstrap css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="components/css/custom.css">
    <link rel="stylesheet" href="components/css/apply.css">
     <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
</head>

<body>
    <section class="customBox">
        <header class="text-center my-4 pb-3">
            <nav>
                <img src="components/images/blak logo.png" alt="logo">
            </nav>
        </header>

        <div class="container text-center">
            <div class="row">
                <div class="col-12 py-3">
                    <h2 class="customHeading">Apply for Installments</h2>

                    <div class="row py-3 text-left">
                        <div class="col-6">
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>No Credit Check</p>
                                </div>
                            </div>
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>Instant Approval</p>
                                </div>
                            </div>
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>$10/Month Flat Rate</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>No Hidden Fees</p>
                                </div>
                            </div>
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>No Interest Charges</p>
                                </div>
                            </div>
                            <div class="iconWithTxt">
                                <div class="checkIcon">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <div>
                                    <p>Access to Snatch Builder</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="py-3 ">
                        <p class="text-left">Submit an application for Snatch Monthly Installments. This lets you make $10
                            monthly payments for 24 months in order to purchase Snatch Builder.</p>
                    </div>

                    <div class="py-3 ">
                        <p class="text-left">We only ask for information needed to set up your account and start
                            building your credit history.</p>
                    </div>


                    <div class="py-3">
                        <form autocomplete="off" class="cmxform" id="applyForm" method="POST" action="apply.php">

                            <?php if(isset($errorMessage) && !empty($errorMessage)){ ?>
                                <div id="alertMsg">
                                    <p><?php echo $errorMessage; ?></p>
                                </div>
                            <?php } ?>

                            <div class="customForm">
                                <input class="form__input" type="text" id="firstName" name="firstName" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">First Name</span>
                            </div>
                            <div class="customForm text-left mb-n2">
                                <input class="form__input" type="text" id="middleName" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">Middle Name</span>
                                <p>Optional</p>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="lastName" name="lastName" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">Last Name</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="mobileNumber" name="mobileNumber"
                                    maxlength="11" placeholder=" " autocomplete="false">
                                <span class="form__label">Mobile Phone</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="birthday" name="birthday" maxlength="10"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">Birthday (MM-DD-YYYY)</span>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="streetAddress" name="streetAddress"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">Street Address</span>
                            </div>
                            <div class="customForm text-left mb-n2">
                                <input class="form__input" type="text" id="aptNumber" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">Apt Number</span>
                                <p>Optional</p>
                            </div>
                            <div class="customForm">
                                <input class="form__input" type="text" id="city" name="city" placeholder=" "
                                    autocomplete="false">
                                <span class="form__label">City</span>
                            </div>
                            <div class="customForm">
                                <div id="stateTopText">
                                    <select class="customSelect" name="state" id="state" onfocus="focusInSelect()"
                                        onfocusout="focusOutSelect()">
                                        <option value=""></option>
                                        <option value="Alabama">Alabama</option>
                                        <option value="Alaska">Alaska</option>
										<option value="Arizona">Arizona</option>
                                        <option value="Arkansas">Arkansas</option>
                                        <option value="Colorado">Colorado </option>
										<option value="Connecticut">Connecticut </option>
										<option value="Delaware">Delaware </option>
										<option value="Florida">Florida </option>
										<option value="Georgia">Georgia </option>
										<option value="Hawaii">Hawaii </option>
										<option value="Idaho">Idaho </option>
										<option value="Illinois">Illinois </option>
										<option value="Indiana">Indiana </option>
										<option value="Iowa"> Iowa</option>
										<option value="Kansas">Kansas </option>
										<option value="Kentucky">Kentucky </option>
										<option value="Louisiana">Louisiana </option>
										<option value="Maine">Maine </option>
										<option value="Maryland"> Maryland </option>
										<option value="Massachusetts">Massachusetts </option>
										<option value="Minnesota">Minnesota </option>
										<option value="Mississippi">Mississippi</option>
										<option value="Missouri">Missouri </option>
										<option value="Montana">Montana </option>
										<option value="Nebraska">Nebraska</option>
										<option value="Nevada">Nevada </option>
										<option value="New Hampshire">New Hampshire </option>
										<option value="New Jersey"> New Jersey </option>
										<option value="New Mexico">New Mexico </option>
										<option value="New York">New York </option>
										<option value="North Carolina">North Carolina </option>
										<option value="North Dakota">North Dakota </option>
										<option value="Ohio">Ohio </option>
										<option value="Oklahoma">Oklahoma </option>
										<option value="Oregon">Oregon </option>
										<option value="Pennsylvania"> Pennsylvania </option>
										<option value="Puerto Rico">Puerto Rico </option>
										<option value="South Carolina">South Carolina </option>
										<option value="South Dakota">South Dakota </option>
										<option value="Tennessee">Tennessee </option>
										<option value="Texas">Texas </option>
										<option value="U.S. Virgin Islands">U.S. Virgin Islands </option>
										<option value="Utah">Utah </option>
										<option value="Vermont">Vermont </option>
										<option value="Virginia">Virginia </option>
										<option value="Washington">Washington </option>
										<option value="West Virginia">West Virginia </option>
										<option value="Wisconsin">Wisconsin </option>
										<option value="Wyoming">Wyoming</option>
                                    </select>
                                    <span id="stateAbove">State</span>
                                </div>
                            </div>

                            <div class="customForm">
                                <input class="form__input" type="text" id="zipcode" name="zipcode" maxlength="5"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">Zipcode</span>
                            </div>

                            <div class="customForm">
                                <input class="form__input" type="text" id="SSN" name="SSN" maxlength="11"
                                    placeholder=" " autocomplete="false">
                                <span class="form__label">SSN (XXX-XX-XXXX)</span>
                            </div>

                            <div class="customForm">
                                <input class="form__input" type="text" id="monthlyIncome" name="monthlyIncome"
                                    placeholder=" " autocomplete="false" pattern="^\$\d{1,3}(,\d{3})*(\.\d+)?$" value=""
                                    data-type="currency">
                                <span class="form__label">Monthly Income ($)</span>
                            </div>

                            <div class="custom-control custom-checkbox checkboxFix my-3">
                                <div class="animBtn pulse"></div>
                                <input type="checkbox" class="custom-control-input mr-2 pulse" id="authorization"
                                    onchange="checkboxCheck(this)" type="checkbox" name="authorization" anim="ripple">
                                <label class="custom-control-label" for="authorization">
                                    Authorization for the Social Security Administration to Disclose Your Social
                                    Security Number Verification.
                                </label>
                            </div>

                            <div class="py-3 text-left">
                                <p>
                                    I authorize the Social Security Administration (SSA) to verify and disclose to Snatch
                                    Inc. through SentiLink Verification Services Corp., their service provider for the
                                    purpose of this transaction whether the name, Social Security Number (SSN) and date
                                    of birth I have submitted matches information in SSA records. My consent is for a
                                    one-time validation within the next 10 days.
                                </p>
                            </div>
                            <div class="py-3">
                                <button class="customBtn" anim="ripple">Submit</button>
                            </div>
                        </form>

                        <div class="py-3 text-left">
                            <p>
                                By clicking the SUBMIT button, you are signing the consent for SSA to disclose your SSN
                                Verification to Snatch Inc. and SentiLink Verification Services Corp. You agree that your
                                electronic signature has the same legal meaning, validity, and effect as your
                                handwritten signature.
                            </p>
                        </div>


                    </div>

                    <p class="py-3 text-left">By submitting, I attest that the above information is accurate and true,
                        and I agree to Snatch’s
                        <a class="customLinkColor" href="#">Social Security Number Privacy Protection Policy
                        </a>,
                        <a class="customLinkColor" href="#">Electronic Communications Consent Notice
                        </a>,
                        <a class="customLinkColor" href="#">Consumer Privacy Notice
                        </a> and <a class="customLinkColor" href="#">TheHelloSign’s Terms of Use</a>.
                    </p>
                </div>
            </div>
        </div>
    </section>


    <!-- Jquery js link -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <!-- Bootstrap js link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx"
        crossorigin="anonymous"></script>
    <!-- Input mask jquery plugin link -->
    <script src="components/js-code/jquery.mask.js"></script>
    <!-- custom js code -->
    <script src="components/js-code/main.js"></script>
    <!-- form validation plugin link -->
    <script src="components/js-code/jquery.validate.min.js"></script>
    <script src="components/js-code/apply.js"></script>
    <script>
        $(function () {
            $('#mobileNumber').mask('999-999-9999')
            $('#birthday').mask('99-99-9999');
            $('#zipcode').mask('99999')
            $('#SSN').mask('999-99-9999');
        });
    </script>
</body>

</html>
<?php
    require_once ('database.php');
    //session_destroy();
    if(isset($_SESSION['forgot_email']) && isset($_SESSION['forgot_code']) ){
        //
    }else{
        header('Location: forgotpassword.php');
    }

    $errorMessage = "";
    if(isset($_POST) && !empty($_POST)){
        
        if($_SESSION['forgot_code'] == $_POST['forgot_verify_code']){
            $res = $database->update_Password($_SESSION['forgot_email'], $_POST['password']);
            
            if($res){
                header('LOCATION: login.php');
            }else{
                $errorMessage = "Something went wrong, please try again.";
            }
        }else{
            $errorMessage = "The code entered does not match what we sent you, please try again.";
        }
        
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Snatch | Confirm </title>
    <!-- Bootstrap css link -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <link rel="stylesheet" href="components/css/custom.css?v=1">
    <link rel="stylesheet" href="components/css/signup.css">
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">
</head>
<body>
    


    <section class="customBox">
        <header class="text-center my-4 pb-3">
            <nav>
                <img src="components/images/blak logo.png" alt="logo">
            </nav>
        </header>
    
        <div class="container text-center">
            <div class="row">
                <div class="col-12 py-3">
                    <h2 class="customHeading">Set Up Your Password</h2>
    
                   <div class="text-center mt-3">
                        <form class="cmxform" id="signupForm" method="POST" action="confirm.php">

                            <?php if(isset($errorMessage) && !empty($errorMessage)){ ?>
                                <div id="alertMsg">
                                    <p><?php echo $errorMessage; ?></p>
                                </div>
                            <?php } ?>

                            <div class="customForm">
                                <input required id="" name="forgot_verify_code" type="text" class="form__input" placeholder=" " autocomplete="off">
                                <span class="form__label">Enter Code</span>
                            </div>
                            <div class="customForm">
                                <div class="toggleFix">
                                    <input class="form__input" type="password" name="password" id="password" placeholder=" " autocomplete="off">
                                    <span class="form__label">Password</span>
                                    <div id="firsTtoggle" onclick="showHideFirst()"></div>
                                </div>
                            </div>
                            <div class="customForm">
                                   <div class="toggleFix">
                                        <input class="form__input" type="password" name="confirm_password" id="confirm_password" placeholder=" " autocomplete="off">
                                        <span class="form__label">Confirm Password</span>
                                        <div id="secondToggle" onclick="showHideSecond()"></div>
                                   </div>
                            </div>
                            <div class="text-center py-3 mt-3">
                                <button type="submit" class="customBtn" anim="ripple">Update Password</button>
                            </div>
                        </form>
                    </div> 
    
                </div>
            </div>
        </div>
    </section>



       
    <!-- Jquery js link -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <!-- Bootstrap js link -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
    <!-- custom js code -->
    <script src="components/js-code/main.js"></script>
    <!-- form validation plugin link -->
    <script src="components/js-code/jquery.validate.min.js"></script>
    <script src="components/js-code/signup.js"></script>


</body>
</html>